﻿using System.Transactions;

namespace flow_stuff
{
    internal class Program
    {
        static void Main(string[] args)
        {


            /*
             var x = Convert.ToInt32(Console.ReadLine());
             var y = int.Parse(Console.ReadLine());

             int z;


             z = x + y;



             Console.WriteLine("equals: " + z);
            var x = int.Parse(Console.ReadLine());
            var y = 10;
            
            while (x <= y)
            {
                Console.Write(x);
                Console.Write("-");
                x++;
            }
            Console.ReadLine();
            */

            var x = int.Parse(Console.ReadLine());
            var y = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter your operator(+, -, /, *)");
            var myOperator = string.Empty;




          
            while (myOperator != "+" &&
                myOperator != "-" &&
                myOperator != "/" &&
                myOperator != "*" ||
                (myOperator == "/" && y == 0))
                
            {
                Console.WriteLine("Please choose a valid operand");
                myOperator = Console.ReadLine();
            }


            

            if (myOperator == "+")
            
                Console.WriteLine(x + y);
            

            if (myOperator == "-")
            
                Console.WriteLine(x - y);
            

            if (myOperator == "*")
            
                Console.WriteLine(x * y);
            

            if (myOperator == "/")
            
                Console.WriteLine(x / y);
          }
    }
}