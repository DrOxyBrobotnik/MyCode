﻿using System.Text;

namespace bruh
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Katt myKatt = new Katt(" Kitty.", 34);
            myKatt.Meow();
           
        
          


            


        }



        
     
        
    
    

    
        
    }
}

    
